<?php
    $hostname = "localhost";
    $username = "root";
    $password = "";
    $database = "water"; // Added a semicolon here
    $conn = mysqli_connect($hostname, $username, $password, $database);
?>
